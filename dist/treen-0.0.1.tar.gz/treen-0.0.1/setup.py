from setuptools import setup, find_packages

setup(
    name="treen",
    version="0.0.1",
    author="rebase.energy",
    description="A Python library for energy forecasting using decision trees.",
    packages=find_packages(),
)